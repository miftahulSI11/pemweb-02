
 # Task 1
 ### Buatlah:
 - Fitur Update (mengubah data): Produk dan Pelanggan
 - Fitur Delete (menghapus data): Produk dan Pelanggan
 
 Diperbolehkan untuk belajar bersama
 Dilarang copy paste dan melakukan plagiarism
 
